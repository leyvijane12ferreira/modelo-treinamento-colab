package com.example.livrointerativo

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

class BoasManeirasActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_boas_maneiras)
    }
}
